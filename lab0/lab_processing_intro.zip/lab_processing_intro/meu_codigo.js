var tam; // declaração de variável 

// os códigos de "setup" só executam uma vez 
function setup() {

   tam = parseInt( prompt("Tamanho: ") ); 
}

// os códigos de "draw" executam constantemente 
function draw() {
  ellipse(56, 46, tam, tam);

}
