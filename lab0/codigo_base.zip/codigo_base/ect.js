function lerTexto(x) {
	return prompt(x);
}
function escreva(x) {
	return alert(x);
}
function lerInteiro(x) {
	return parseInt(prompt(x));
}
function lerReal(x) {
	return parseFloat(prompt(x));
}

